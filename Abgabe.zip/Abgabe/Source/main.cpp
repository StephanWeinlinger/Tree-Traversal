#include <iostream>
#include "Controller.h"

int main(int arc, char** argv) {
	Controller controller;
	switch(arc) {
		case 2:
			controller.firstTask(argv);
			break;
		case 3:
			controller.secondTask(argv);
			break;
		default:
			std::cout << "Wrong parameter amount!" << std::endl;
	}
	return 0;
}